from Crypto.Cipher import INSERTE_CIFRADO
from Crypto.Util.Padding import unpad
import binascii

key = b'INSERTE_CLAVE' + b'\x00' * 8  # Clave de 128 bits (16 bytes)
cipher_text_hex = 'inserte_texto_cifrado'  # texto cifrado en hexadecimal

# Convertir el texto cifrado de hexadecimal a bytes
cipher_text_with_iv = binascii.unhexlify(cipher_text_hex)

# Extraer el IV y el texto cifrado
iv = cipher_text_with_iv[:AES.block_size]
cipher_text = cipher_text_with_iv[AES.block_size:]
